from django.shortcuts import render,get_object_or_404
from .models import Question
from django.template import loader
from django.http import Http404



#first we have a functional view...
def index(request):
    latest_question_list = Question.objects.order_by('-date_published')[:5]
    context = {'latest_question_list': latest_question_list}
    return render(request, 'polls/index.html', context)


def detail(request, question_id):
    question = get_object_or_404(Question, pk=question_id)
    return render(request, 'polls/detail.html', {'question': question})

def vote(request, question_id):
    question = get_object_or_404(Question, pk=question_id)
    try:
        selected_choice = question.choice_set.get(pk=request.POST['choice'])
    except (KeyError, Choice.DoesNotExist):
        return render(request, 'polls/detail.html', {
            'question': question,
            'error_message': "You didn't made a poll choice"
        })
    else:
        selected_choice.votes += 1
        selected_choice.save()
        return HttpResponseRedirect(reverse('polls:results', args=(question.id,)))
        

def results(request, question_id):
    question = get_object_or_404(Question, pk=question_id)
    return render(request, 'polls/results.html', {'question': question})


#below are the test views....


# def detail_2(request, question_id):
#     return HttpResponse(f"You're looking at question {question_id}")

# def results_2(request, question_id):
#     response = f"you're looking at results of question {question_id}"
#     return HttpResponse(response)

# def vote_2(request, question_id):
#     return HttpResponse(f"You're voting on question {question_id}")

