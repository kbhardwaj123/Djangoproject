from django.urls import path
from . import views

# add path to the list...
app_name = 'polls'
urlpatterns = [
path('', views.index, name='index'),
path('<int:question_id>/', views.detail, name='detail'),
path('<int:question_id>/results/', views.results, name='results'),
path('<int:question_id>/vote/', views.vote, name='vote'),
]

# extra paths for  tetsing...
# path('<int:question_id>/test', views.detail_2, name='detail'),
# path('<int:question_id>/results/test', views.results_2, name='results'),
# path('<int:question_id>/vote/test', views.vote_2, name='vote'),

